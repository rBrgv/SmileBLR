import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { sb } from '../lib/supabase'
import { fmtD, fmtDT, inr, digits, today } from '../lib/format'
import { useToast } from '../components/Toast'
import Modal from '../components/Modal'
import StatusSelect from '../components/StatusSelect'
import ToothChart, { TOOTH_CONDITIONS } from '../components/ToothChart'
import { PatientForm } from './Patients'
import { AppointmentForm, APPT_STATUSES, completeAppointment } from './Appointments'

const TABS = ['Overview', 'Tooth Chart', 'Medical History', 'Appointments', 'Prescriptions', 'Invoices']

export default function PatientDetail() {
  const { id } = useParams()
  const [d, setD] = useState(null)
  const [tab, setTab] = useState(0)
  const [modal, setModal] = useState(null) // {type, payload}
  const toast = useToast()

  async function load() {
    const [p, mh, teeth, appts, rx, inv, docs] = await Promise.all([
      sb.from('patients').select('*').eq('id', id).single(),
      sb.from('medical_history').select('*').eq('patient_id', id).order('updated_at', { ascending: false }).limit(1),
      sb.from('tooth_chart').select('*').eq('patient_id', id),
      sb.from('appointments').select('*, staff(full_name), treatments(name)').eq('patient_id', id).order('appointment_time', { ascending: false }),
      sb.from('prescriptions').select('*, staff(full_name)').eq('patient_id', id).order('prescribed_date', { ascending: false }),
      sb.from('invoices').select('*').eq('patient_id', id).order('invoice_date', { ascending: false }),
      sb.from('staff').select('*').eq('active', true).eq('role', 'doctor').order('full_name'),
    ])
    setD({ p: p.data, mh: mh.data?.[0] || null, teeth: teeth.data ?? [], appts: appts.data ?? [], rx: rx.data ?? [], inv: inv.data ?? [], docs: docs.data ?? [] })
  }
  useEffect(() => { load() }, [id])

  if (!d?.p) return <div className="empty">Loading…</div>
  const { p } = d

  async function setApptStatus(a, status) {
    const { error } = await sb.from('appointments').update({ status }).eq('id', a.id)
    if (error) return toast('Error: ' + error.message)
    if (status === 'completed') { await completeAppointment(id); toast('Visit completed · 6-month recall scheduled') }
    load()
  }
  async function setInvStatus(vid, status) {
    const { error } = await sb.from('invoices').update({ payment_status: status }).eq('id', vid)
    if (error) return toast('Error: ' + error.message)
    toast('Invoice ' + status); load()
  }

  return (
    <>
      <div className="pd-head">
        <div>
          <h3>{p.full_name}</h3>
          <div className="sub">
            {p.phone}{p.email && ' · ' + p.email}{p.date_of_birth && ' · DOB ' + fmtD(p.date_of_birth)}{p.gender && ' · ' + p.gender}<br />
            {p.address && <>{p.address}<br /></>}
            Registered {fmtD(p.created_at)} · Consent {p.consent_given ? '✓ ' + fmtD(p.consent_date) : '✗'}
          </div>
        </div>
        <div>
          <button className="btn ghost sm" onClick={() => setModal({ type: 'edit' })}>Edit</button>{' '}
          <a className="btn sm green" target="_blank" rel="noreferrer" href={'https://wa.me/' + digits(p.phone)}>WhatsApp</a>
        </div>
      </div>

      <div className="tabs">
        {TABS.map((t, i) => (
          <button key={t} className={'tab' + (tab === i ? ' active' : '')} onClick={() => setTab(i)}>{t}</button>
        ))}
      </div>

      {tab === 0 && (
        <>
          <div className="stats">
            <div className="stat"><b>{d.appts.length}</b><span>Appointments</span></div>
            <div className="stat pink"><b>{d.teeth.filter(t => t.condition && t.condition !== 'Healthy').length}</b><span>Teeth flagged</span></div>
            <div className="stat gold"><b>{d.rx.length}</b><span>Prescriptions</span></div>
            <div className="stat green"><b>{inr(d.inv.filter(v => v.payment_status === 'paid').reduce((a, v) => a + Number(v.amount), 0))}</b><span>Paid to date</span></div>
          </div>
          <button className="btn" onClick={() => setModal({ type: 'appt' })}>+ Appointment</button>{' '}
          <button className="btn ghost" onClick={() => setModal({ type: 'rx' })}>+ Prescription</button>{' '}
          <button className="btn ghost" onClick={() => setModal({ type: 'inv' })}>+ Invoice</button>
        </>
      )}

      {tab === 1 && <ToothChart teeth={d.teeth} onSelect={(n, t) => setModal({ type: 'tooth', n, t })} />}

      {tab === 2 && <MedicalHistory patientId={id} mh={d.mh} onSaved={load} />}

      {tab === 3 && (
        <>
          <button className="btn" style={{ marginBottom: '.75rem' }} onClick={() => setModal({ type: 'appt' })}>+ New appointment</button>
          {!d.appts.length ? <div className="empty">No appointments.</div> : (
            <table className="tbl">
              <thead><tr><th>When</th><th>Doctor</th><th>Treatment</th><th>Room</th><th>Status</th></tr></thead>
              <tbody>{d.appts.map(a => (
                <tr key={a.id}>
                  <td>{fmtDT(a.appointment_time)}</td><td>{a.staff?.full_name || '—'}</td>
                  <td>{a.treatments?.name || '—'}</td><td>{a.floor_room || '—'}</td>
                  <td><StatusSelect value={a.status} options={APPT_STATUSES} onChange={s => setApptStatus(a, s)} /></td>
                </tr>
              ))}</tbody>
            </table>
          )}
        </>
      )}

      {tab === 4 && (
        <>
          <button className="btn" style={{ marginBottom: '.75rem' }} onClick={() => setModal({ type: 'rx' })}>+ New prescription</button>
          {!d.rx.length ? <div className="empty">No prescriptions.</div> : (
            <table className="tbl">
              <thead><tr><th>Date</th><th>Medicine</th><th>Dosage</th><th>Duration</th><th>By</th></tr></thead>
              <tbody>{d.rx.map(r => (
                <tr key={r.id}>
                  <td>{fmtD(r.prescribed_date)}</td><td>{r.medicine_name}</td>
                  <td>{r.dosage || '—'}</td><td>{r.duration || '—'}</td><td>{r.staff?.full_name || '—'}</td>
                </tr>
              ))}</tbody>
            </table>
          )}
        </>
      )}

      {tab === 5 && (
        <>
          <button className="btn" style={{ marginBottom: '.75rem' }} onClick={() => setModal({ type: 'inv' })}>+ New invoice</button>
          {!d.inv.length ? <div className="empty">No invoices.</div> : (
            <table className="tbl">
              <thead><tr><th>Date</th><th>Amount</th><th>Method</th><th>Status</th></tr></thead>
              <tbody>{d.inv.map(v => (
                <tr key={v.id}>
                  <td>{fmtD(v.invoice_date)}</td><td>{inr(v.amount)}</td><td>{v.payment_method || '—'}</td>
                  <td><StatusSelect value={v.payment_status} options={['pending', 'partial', 'paid', 'refunded']} onChange={s => setInvStatus(v.id, s)} /></td>
                </tr>
              ))}</tbody>
            </table>
          )}
        </>
      )}

      {modal?.type === 'edit' && <PatientForm patient={p} onClose={() => setModal(null)} onDone={() => { setModal(null); load() }} />}
      {modal?.type === 'appt' && <AppointmentForm patientId={id} onClose={() => setModal(null)} onDone={() => { setModal(null); load() }} />}
      {modal?.type === 'tooth' && <ToothForm patientId={id} n={modal.n} t={modal.t} doctors={d.docs} onClose={() => setModal(null)} onDone={() => { setModal(null); load() }} />}
      {modal?.type === 'rx' && <RxForm patientId={id} doctors={d.docs} onClose={() => setModal(null)} onDone={() => { setModal(null); load() }} />}
      {modal?.type === 'inv' && <InvoiceForm patientId={id} onClose={() => setModal(null)} onDone={() => { setModal(null); load() }} />}
    </>
  )
}

function MedicalHistory({ patientId, mh, onSaved }) {
  const [f, setF] = useState({
    condition: mh?.condition || '', allergies: mh?.allergies || '', current_medications: mh?.current_medications || '',
    pregnancy_status: mh?.pregnancy_status || false, notes: mh?.notes || '',
  })
  const toast = useToast()
  const set = k => e => setF(x => ({ ...x, [k]: e.target.value }))

  async function save() {
    const rec = {
      patient_id: patientId, condition: f.condition.trim() || null, allergies: f.allergies.trim() || null,
      current_medications: f.current_medications.trim() || null, pregnancy_status: f.pregnancy_status, notes: f.notes.trim() || null,
    }
    const q = mh?.id ? sb.from('medical_history').update(rec).eq('id', mh.id) : sb.from('medical_history').insert(rec)
    const { error } = await q
    if (error) return toast('Error: ' + error.message)
    toast('Medical history saved'); onSaved()
  }

  return (
    <div style={{ maxWidth: 640 }}>
      <div className="mrow">
        <div><label>Conditions</label><input placeholder="Diabetes, hypertension…" value={f.condition} onChange={set('condition')} /></div>
        <div><label>Allergies</label><input placeholder="Penicillin…" value={f.allergies} onChange={set('allergies')} /></div>
      </div>
      <label>Current medications</label><input value={f.current_medications} onChange={set('current_medications')} />
      <label style={{ display: 'flex', alignItems: 'center', gap: '.5rem', textTransform: 'none', fontSize: '.78rem', color: 'var(--ink)' }}>
        <input type="checkbox" style={{ width: 'auto' }} checked={f.pregnancy_status}
          onChange={e => setF(x => ({ ...x, pregnancy_status: e.target.checked }))} /> Pregnancy status
      </label>
      <label>Notes</label><textarea rows={2} value={f.notes} onChange={set('notes')} />
      <button className="btn" style={{ marginTop: '1rem' }} onClick={save}>Save medical history</button>
    </div>
  )
}

function ToothForm({ patientId, n, t, doctors, onClose, onDone }) {
  const [f, setF] = useState({ condition: t?.condition || 'Healthy', treating_doctor_id: t?.treating_doctor_id || '', notes: t?.notes || '' })
  const toast = useToast()
  async function save() {
    const rec = {
      patient_id: patientId, tooth_number: n, condition: f.condition,
      treating_doctor_id: f.treating_doctor_id || null, notes: f.notes.trim() || null, treatment_date: today(),
    }
    const q = t?.id ? sb.from('tooth_chart').update(rec).eq('id', t.id) : sb.from('tooth_chart').insert(rec)
    const { error } = await q
    if (error) return toast('Error: ' + error.message)
    toast(`Tooth ${n} saved`); onDone()
  }
  return (
    <Modal title={'Tooth ' + n} onClose={onClose}>
      <label>Condition</label>
      <select value={f.condition} onChange={e => setF(x => ({ ...x, condition: e.target.value }))}>
        {TOOTH_CONDITIONS.map(c => <option key={c}>{c}</option>)}
      </select>
      <label>Treating doctor</label>
      <select value={f.treating_doctor_id} onChange={e => setF(x => ({ ...x, treating_doctor_id: e.target.value }))}>
        <option value="">—</option>{doctors.map(d => <option key={d.id} value={d.id}>{d.full_name}</option>)}
      </select>
      <label>Notes</label><input value={f.notes} onChange={e => setF(x => ({ ...x, notes: e.target.value }))} />
      <button className="btn" onClick={save}>Save</button>
    </Modal>
  )
}

function RxForm({ patientId, doctors, onClose, onDone }) {
  const [f, setF] = useState({ medicine_name: '', dosage: '', duration: '', prescribed_by: '', notes: '' })
  const toast = useToast()
  const set = k => e => setF(x => ({ ...x, [k]: e.target.value }))
  async function save() {
    if (!f.medicine_name.trim()) return toast('Medicine name required.')
    const { error } = await sb.from('prescriptions').insert({
      patient_id: patientId, medicine_name: f.medicine_name.trim(), dosage: f.dosage.trim() || null,
      duration: f.duration.trim() || null, prescribed_by: f.prescribed_by || null, notes: f.notes.trim() || null,
    })
    if (error) return toast('Error: ' + error.message)
    toast('Prescription saved'); onDone()
  }
  return (
    <Modal title="New prescription" onClose={onClose}>
      <label>Medicine *</label><input value={f.medicine_name} onChange={set('medicine_name')} />
      <div className="mrow">
        <div><label>Dosage</label><input placeholder="500mg twice daily" value={f.dosage} onChange={set('dosage')} /></div>
        <div><label>Duration</label><input placeholder="5 days" value={f.duration} onChange={set('duration')} /></div>
      </div>
      <label>Prescribed by</label>
      <select value={f.prescribed_by} onChange={set('prescribed_by')}>
        <option value="">—</option>{doctors.map(d => <option key={d.id} value={d.id}>{d.full_name}</option>)}
      </select>
      <label>Notes</label><input value={f.notes} onChange={set('notes')} />
      <button className="btn" onClick={save}>Save prescription</button>
    </Modal>
  )
}

function InvoiceForm({ patientId, onClose, onDone }) {
  const [f, setF] = useState({ amount: '', payment_method: '', notes: '' })
  const toast = useToast()
  const set = k => e => setF(x => ({ ...x, [k]: e.target.value }))
  async function save() {
    const amt = parseFloat(f.amount)
    if (!amt) return toast('Enter an amount.')
    const { error } = await sb.from('invoices').insert({
      patient_id: patientId, amount: amt, payment_method: f.payment_method || null, notes: f.notes.trim() || null,
    })
    if (error) return toast('Error: ' + error.message)
    toast('Invoice created'); onDone()
  }
  return (
    <Modal title="New invoice" onClose={onClose}>
      <label>Amount (INR) *</label><input type="number" value={f.amount} onChange={set('amount')} />
      <label>Payment method</label>
      <select value={f.payment_method} onChange={set('payment_method')}>
        <option value="">—</option><option>cash</option><option>card</option><option>upi</option><option>insurance</option>
      </select>
      <label>Notes</label><input value={f.notes} onChange={set('notes')} />
      <button className="btn" onClick={save}>Save invoice</button>
    </Modal>
  )
}
