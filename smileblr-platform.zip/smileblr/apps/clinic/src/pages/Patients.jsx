import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { sb } from '../lib/supabase'
import { fmtD } from '../lib/format'
import { useToast } from '../components/Toast'
import Modal from '../components/Modal'

export function PatientForm({ patient = {}, onDone, onClose }) {
  const [f, setF] = useState({
    full_name: patient.full_name || '', phone: patient.phone || '', email: patient.email || '',
    date_of_birth: patient.date_of_birth || '', gender: patient.gender || '', address: patient.address || '',
    emergency_contact_name: patient.emergency_contact_name || '', emergency_contact_phone: patient.emergency_contact_phone || '',
  })
  const toast = useToast()
  const set = k => e => setF(x => ({ ...x, [k]: e.target.value }))

  async function save() {
    if (!f.full_name.trim() || !f.phone.trim()) return toast('Name and phone are required.')
    const rec = Object.fromEntries(Object.entries(f).map(([k, v]) => [k, typeof v === 'string' && !v.trim() ? null : v]))
    let id = patient.id
    if (id) {
      const { error } = await sb.from('patients').update(rec).eq('id', id)
      if (error) return toast('Error: ' + error.message)
      toast('Patient updated')
    } else {
      rec.consent_given = true; rec.consent_date = new Date().toISOString()
      const { data, error } = await sb.from('patients').insert(rec).select().single()
      if (error) return toast('Error: ' + error.message)
      id = data.id; toast('Patient created')
    }
    onDone(id)
  }

  return (
    <Modal title={(patient.id ? 'Edit' : 'New') + ' patient'} onClose={onClose}>
      <div className="mrow">
        <div><label>Full name *</label><input value={f.full_name} onChange={set('full_name')} /></div>
        <div><label>Phone *</label><input value={f.phone} onChange={set('phone')} /></div>
      </div>
      <div className="mrow">
        <div><label>Email</label><input value={f.email} onChange={set('email')} /></div>
        <div><label>Date of birth</label><input type="date" value={f.date_of_birth || ''} onChange={set('date_of_birth')} /></div>
      </div>
      <div className="mrow">
        <div><label>Gender</label><select value={f.gender} onChange={set('gender')}>
          <option value="">—</option><option>Female</option><option>Male</option><option>Other</option></select></div>
        <div><label>Emergency contact</label><input placeholder="Name" value={f.emergency_contact_name} onChange={set('emergency_contact_name')} /></div>
      </div>
      <div className="mrow">
        <div><label>Emergency phone</label><input value={f.emergency_contact_phone} onChange={set('emergency_contact_phone')} /></div>
        <div></div>
      </div>
      <label>Address</label><textarea rows={2} value={f.address} onChange={set('address')} />
      <button className="btn" onClick={save}>Save patient</button>
    </Modal>
  )
}

export default function Patients() {
  const [rows, setRows] = useState(null)
  const [q, setQ] = useState('')
  const [showForm, setShowForm] = useState(false)
  const nav = useNavigate()

  useEffect(() => {
    sb.from('patients').select('*').order('created_at', { ascending: false }).limit(500)
      .then(({ data }) => setRows(data ?? []))
  }, [])

  if (!rows) return <div className="empty">Loading…</div>
  const view = rows.filter(p => !q || (p.full_name || '').toLowerCase().includes(q.toLowerCase()) || (p.phone || '').includes(q))

  return (
    <>
      <div className="pagehead">
        <h2>Patients</h2>
        <button className="btn" onClick={() => setShowForm(true)}>+ New patient</button>
      </div>
      <div className="bar"><input placeholder="Search name / phone…" value={q} onChange={e => setQ(e.target.value)} /></div>
      {!view.length ? <div className="empty">No patients yet. Convert a booking or add one.</div> : (
        <table className="tbl">
          <thead><tr><th>Name</th><th>Phone</th><th>DOB</th><th>Registered</th><th></th></tr></thead>
          <tbody>{view.map(p => (
            <tr key={p.id}>
              <td className="link" onClick={() => nav('/patients/' + p.id)}>{p.full_name}</td>
              <td>{p.phone}</td>
              <td>{fmtD(p.date_of_birth)}</td>
              <td>{fmtD(p.created_at)}</td>
              <td><button className="btn sm ghost" onClick={() => nav('/patients/' + p.id)}>Open</button></td>
            </tr>
          ))}</tbody>
        </table>
      )}
      {showForm && <PatientForm onClose={() => setShowForm(false)} onDone={id => { setShowForm(false); nav('/patients/' + id) }} />}
    </>
  )
}
