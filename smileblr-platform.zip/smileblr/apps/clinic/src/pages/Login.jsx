import { useState } from 'react'
import { sb } from '../lib/supabase'

export default function Login() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [err, setErr] = useState('')

  async function signIn() {
    setErr('')
    const { error } = await sb.auth.signInWithPassword({ email: email.trim(), password })
    if (error) setErr(error.message)
  }

  return (
    <div className="login">
      <h2>Smile Bengaluru · Clinic</h2>
      <p>Staff sign in</p>
      <label>Email</label>
      <input type="email" value={email} onChange={e => setEmail(e.target.value)} autoComplete="username" />
      <label>Password</label>
      <input type="password" value={password} onChange={e => setPassword(e.target.value)}
        autoComplete="current-password" onKeyDown={e => e.key === 'Enter' && signIn()} />
      <button className="btn" style={{ width: '100%', marginTop: '1.25rem' }} onClick={signIn}>Sign in</button>
      {err && <div className="err">{err}</div>}
    </div>
  )
}
