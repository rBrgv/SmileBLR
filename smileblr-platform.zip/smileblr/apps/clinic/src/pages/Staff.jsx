import { useEffect, useState } from 'react'
import { sb } from '../lib/supabase'
import { useToast } from '../components/Toast'
import Modal from '../components/Modal'

export default function Staff() {
  const [rows, setRows] = useState(null)
  const [show, setShow] = useState(false)
  const toast = useToast()

  async function load() {
    const { data } = await sb.from('staff').select('*').order('full_name')
    setRows(data ?? [])
  }
  useEffect(() => { load() }, [])

  async function toggle(id, active) {
    await sb.from('staff').update({ active }).eq('id', id)
    toast('Updated'); load()
  }

  if (!rows) return <div className="empty">Loading…</div>
  return (
    <>
      <div className="pagehead">
        <h2>Staff</h2>
        <button className="btn" onClick={() => setShow(true)}>+ Add staff</button>
      </div>
      {!rows.length ? (
        <div className="empty">Add Dr. Prithvi and the team here first — doctors appear in appointment and prescription dropdowns.</div>
      ) : (
        <table className="tbl">
          <thead><tr><th>Name</th><th>Role</th><th>Specialization</th><th>Floor</th><th>Phone</th><th>Active</th></tr></thead>
          <tbody>{rows.map(s => (
            <tr key={s.id}>
              <td>{s.full_name}</td><td>{s.role}</td><td>{s.specialization || '—'}</td>
              <td>{s.floor_assigned ?? '—'}</td><td>{s.phone || '—'}</td>
              <td><input type="checkbox" style={{ width: 'auto' }} checked={s.active} onChange={e => toggle(s.id, e.target.checked)} /></td>
            </tr>
          ))}</tbody>
        </table>
      )}
      {show && <StaffForm onClose={() => setShow(false)} onDone={() => { setShow(false); load() }} />}
    </>
  )
}

function StaffForm({ onClose, onDone }) {
  const [f, setF] = useState({ full_name: '', role: 'doctor', floor_assigned: '', specialization: '', qualifications: '', phone: '', email: '' })
  const toast = useToast()
  const set = k => e => setF(x => ({ ...x, [k]: e.target.value }))
  async function save() {
    if (!f.full_name.trim()) return toast('Name required.')
    const { error } = await sb.from('staff').insert({
      full_name: f.full_name.trim(), role: f.role,
      specialization: f.specialization.trim() || null, qualifications: f.qualifications.trim() || null,
      floor_assigned: parseInt(f.floor_assigned) || null, phone: f.phone.trim() || null, email: f.email.trim() || null,
    })
    if (error) return toast('Error: ' + error.message)
    toast('Staff added'); onDone()
  }
  return (
    <Modal title="Add staff member" onClose={onClose}>
      <label>Full name *</label><input value={f.full_name} onChange={set('full_name')} />
      <div className="mrow">
        <div><label>Role</label><select value={f.role} onChange={set('role')}>
          {['doctor', 'receptionist', 'assistant', 'admin'].map(r => <option key={r}>{r}</option>)}</select></div>
        <div><label>Floor</label><input type="number" value={f.floor_assigned} onChange={set('floor_assigned')} /></div>
      </div>
      <label>Specialization</label><input placeholder="Oral & Maxillofacial Surgery" value={f.specialization} onChange={set('specialization')} />
      <label>Qualifications</label><input placeholder="MDS, MOMS RCPS Glasgow" value={f.qualifications} onChange={set('qualifications')} />
      <div className="mrow">
        <div><label>Phone</label><input value={f.phone} onChange={set('phone')} /></div>
        <div><label>Email</label><input value={f.email} onChange={set('email')} /></div>
      </div>
      <button className="btn" onClick={save}>Save</button>
    </Modal>
  )
}
