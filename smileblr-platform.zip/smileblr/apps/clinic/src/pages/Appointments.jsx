import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { sb } from '../lib/supabase'
import { fmtT, today } from '../lib/format'
import { useToast } from '../components/Toast'
import Modal from '../components/Modal'
import StatusSelect from '../components/StatusSelect'

export const APPT_STATUSES = ['scheduled', 'confirmed', 'in_progress', 'completed', 'cancelled', 'no_show']

// Marking a visit completed schedules the 6-month recall automatically.
export async function completeAppointment(patientId) {
  const due = new Date(); due.setMonth(due.getMonth() + 6)
  await sb.from('recall_reminders').insert({
    patient_id: patientId, last_visit_date: today(), recall_due_date: due.toISOString().slice(0, 10),
  })
}

export function AppointmentForm({ patientId, defaultDate, onDone, onClose }) {
  const [patients, setPatients] = useState([])
  const [doctors, setDoctors] = useState([])
  const [treatments, setTreatments] = useState([])
  const [f, setF] = useState({ patient_id: patientId || '', date: defaultDate || today(), time: '10:00', doctor_id: '', treatment_id: '', floor_room: '', duration: 30, notes: '' })
  const toast = useToast()

  useEffect(() => {
    sb.from('patients').select('id,full_name,phone').order('full_name').then(({ data }) => {
      setPatients(data ?? [])
      if (!patientId && data?.length) setF(x => ({ ...x, patient_id: data[0].id }))
    })
    sb.from('staff').select('*').eq('active', true).eq('role', 'doctor').order('full_name').then(({ data }) => setDoctors(data ?? []))
    sb.from('treatments').select('*').order('name').then(({ data }) => setTreatments(data ?? []))
  }, [])

  async function save() {
    if (!f.patient_id) return toast('Pick a patient.')
    const { error } = await sb.from('appointments').insert({
      patient_id: f.patient_id, doctor_id: f.doctor_id || null, treatment_id: f.treatment_id || null,
      floor_room: f.floor_room.trim() || null, appointment_time: new Date(f.date + 'T' + f.time + ':00').toISOString(),
      duration_minutes: parseInt(f.duration) || 30, notes: f.notes.trim() || null,
    })
    if (error) return toast('Error: ' + error.message)
    toast('Appointment created'); onDone()
  }

  const set = k => e => setF(x => ({ ...x, [k]: e.target.value }))
  return (
    <Modal title="New appointment" onClose={onClose}>
      <label>Patient *</label>
      <select value={f.patient_id} onChange={set('patient_id')}>
        {patients.map(p => <option key={p.id} value={p.id}>{p.full_name} · {p.phone}</option>)}
      </select>
      <div className="mrow">
        <div><label>Date *</label><input type="date" value={f.date} onChange={set('date')} /></div>
        <div><label>Time *</label><input type="time" value={f.time} onChange={set('time')} /></div>
      </div>
      <div className="mrow">
        <div><label>Doctor</label><select value={f.doctor_id} onChange={set('doctor_id')}>
          <option value="">—</option>{doctors.map(d => <option key={d.id} value={d.id}>{d.full_name}</option>)}</select></div>
        <div><label>Treatment</label><select value={f.treatment_id} onChange={set('treatment_id')}>
          <option value="">—</option>{treatments.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}</select></div>
      </div>
      <div className="mrow">
        <div><label>Floor / room</label><input placeholder="Floor 2, Room 1" value={f.floor_room} onChange={set('floor_room')} /></div>
        <div><label>Duration (min)</label><input type="number" value={f.duration} onChange={set('duration')} /></div>
      </div>
      <label>Notes</label><input value={f.notes} onChange={set('notes')} />
      <button className="btn" onClick={save}>Save appointment</button>
    </Modal>
  )
}

export default function Appointments() {
  const [date, setDate] = useState(today())
  const [rows, setRows] = useState(null)
  const [showForm, setShowForm] = useState(false)
  const toast = useToast()
  const nav = useNavigate()

  async function load() {
    const from = new Date(date + 'T00:00:00'), to = new Date(from); to.setDate(to.getDate() + 1)
    const { data, error } = await sb.from('appointments')
      .select('*, patients(full_name,phone), staff(full_name), treatments(name)')
      .gte('appointment_time', from.toISOString()).lt('appointment_time', to.toISOString())
      .order('appointment_time')
    if (error) return toast('Error: ' + error.message)
    setRows(data)
  }
  useEffect(() => { load() }, [date])

  async function setStatus(a, status) {
    const { error } = await sb.from('appointments').update({ status }).eq('id', a.id)
    if (error) return toast('Error: ' + error.message)
    if (status === 'completed') { await completeAppointment(a.patient_id); toast('Visit completed · 6-month recall scheduled') }
    else toast('Appointment ' + status.replace('_', ' '))
    load()
  }

  return (
    <>
      <div className="pagehead">
        <h2>Appointments</h2>
        <button className="btn" onClick={() => setShowForm(true)}>+ New appointment</button>
      </div>
      <div className="bar"><input type="date" style={{ maxWidth: 180 }} value={date} onChange={e => setDate(e.target.value)} /></div>
      {!rows ? <div className="empty">Loading…</div> : !rows.length ? <div className="empty">No appointments on this day.</div> : (
        <table className="tbl">
          <thead><tr><th>Time</th><th>Patient</th><th>Doctor</th><th>Treatment</th><th>Room</th><th>Status</th></tr></thead>
          <tbody>{rows.map(a => (
            <tr key={a.id}>
              <td>{fmtT(a.appointment_time)}</td>
              <td className="link" onClick={() => nav('/patients/' + a.patient_id)}>{a.patients?.full_name}</td>
              <td>{a.staff?.full_name || '—'}</td>
              <td>{a.treatments?.name || '—'}</td>
              <td>{a.floor_room || '—'}</td>
              <td><StatusSelect value={a.status} options={APPT_STATUSES} onChange={s => setStatus(a, s)} /></td>
            </tr>
          ))}</tbody>
        </table>
      )}
      {showForm && <AppointmentForm defaultDate={date} onClose={() => setShowForm(false)} onDone={() => { setShowForm(false); load() }} />}
    </>
  )
}
