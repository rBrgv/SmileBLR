import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { sb } from '../lib/supabase'
import { fmtT, today } from '../lib/format'
import { useToast } from '../components/Toast'
import StatusSelect from '../components/StatusSelect'
import { completeAppointment, APPT_STATUSES } from './Appointments'

export default function Dashboard() {
  const [stats, setStats] = useState(null)
  const [todays, setTodays] = useState([])
  const toast = useToast()
  const nav = useNavigate()

  async function load() {
    const from = new Date(); from.setHours(0, 0, 0, 0)
    const to = new Date(from); to.setDate(to.getDate() + 1)
    const [nb, pt, ap, due] = await Promise.all([
      sb.from('bookings').select('id', { count: 'exact', head: true }).eq('status', 'new'),
      sb.from('patients').select('id', { count: 'exact', head: true }),
      sb.from('appointments').select('*, patients(full_name), staff(full_name), treatments(name)')
        .gte('appointment_time', from.toISOString()).lt('appointment_time', to.toISOString())
        .order('appointment_time'),
      sb.from('recall_reminders').select('id', { count: 'exact', head: true })
        .lte('recall_due_date', today()).eq('reminder_sent', false),
    ])
    setStats({ nb: nb.count ?? 0, pt: pt.count ?? 0, due: due.count ?? 0 })
    setTodays(ap.data ?? [])
  }
  useEffect(() => { load() }, [])

  async function setStatus(a, status) {
    const { error } = await sb.from('appointments').update({ status }).eq('id', a.id)
    if (error) return toast('Error: ' + error.message)
    if (status === 'completed') { await completeAppointment(a.patient_id); toast('Visit completed · 6-month recall scheduled') }
    else toast('Appointment ' + status.replace('_', ' '))
    load()
  }

  if (!stats) return <div className="empty">Loading…</div>
  return (
    <>
      <div className="pagehead">
        <h2>Dashboard</h2>
        <div>{new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' })}</div>
      </div>
      <div className="stats">
        <div className="stat pink"><b>{stats.nb}</b><span>New bookings</span></div>
        <div className="stat"><b>{todays.length}</b><span>Appointments today</span></div>
        <div className="stat green"><b>{stats.pt}</b><span>Patients</span></div>
        <div className="stat gold"><b>{stats.due}</b><span>Recalls due</span></div>
      </div>
      <h2 style={{ fontSize: '.95rem', fontWeight: 500, marginBottom: '.75rem' }}>Today's appointments</h2>
      {!todays.length ? <div className="empty">No appointments scheduled for today.</div> : (
        <table className="tbl">
          <thead><tr><th>Time</th><th>Patient</th><th>Doctor</th><th>Treatment</th><th>Room</th><th>Status</th></tr></thead>
          <tbody>{todays.map(a => (
            <tr key={a.id}>
              <td>{fmtT(a.appointment_time)}</td>
              <td className="link" onClick={() => nav('/patients/' + a.patient_id)}>{a.patients?.full_name}</td>
              <td>{a.staff?.full_name || '—'}</td>
              <td>{a.treatments?.name || '—'}</td>
              <td>{a.floor_room || '—'}</td>
              <td><StatusSelect value={a.status} options={APPT_STATUSES} onChange={s => setStatus(a, s)} /></td>
            </tr>
          ))}</tbody>
        </table>
      )}
    </>
  )
}
