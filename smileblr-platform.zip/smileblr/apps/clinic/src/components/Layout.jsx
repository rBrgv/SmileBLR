import { NavLink, Outlet } from 'react-router-dom'
import { sb } from '../lib/supabase'

const links = [
  ['/', 'Dashboard'], ['/bookings', 'Bookings'], ['/patients', 'Patients'],
  ['/appointments', 'Appointments'], ['/invoices', 'Invoices'], ['/recall', 'Recall Reminders'],
  ['/treatments', 'Treatments'], ['/inventory', 'Inventory'], ['/staff', 'Staff'],
]

export default function Layout() {
  return (
    <div className="shell">
      <nav className="side">
        <div className="brand">Smile Bengaluru<span>Clinic Management</span></div>
        {links.map(([to, label]) => (
          <NavLink key={to} to={to} end={to === '/'}
            className={({ isActive }) => 'nav-item' + (isActive ? ' active' : '')}>{label}</NavLink>
        ))}
        <button className="out" onClick={async () => { await sb.auth.signOut(); location.reload() }}>Sign out</button>
      </nav>
      <main className="main"><Outlet /></main>
    </div>
  )
}
