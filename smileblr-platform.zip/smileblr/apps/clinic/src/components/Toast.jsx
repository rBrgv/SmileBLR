import { createContext, useContext, useState, useCallback } from 'react'

const ToastCtx = createContext(() => {})
export const useToast = () => useContext(ToastCtx)

export function ToastProvider({ children }) {
  const [msg, setMsg] = useState(null)
  const toast = useCallback(m => {
    setMsg(m)
    setTimeout(() => setMsg(null), 2600)
  }, [])
  return (
    <ToastCtx.Provider value={toast}>
      {children}
      {msg && <div className="toast">{msg}</div>}
    </ToastCtx.Provider>
  )
}
