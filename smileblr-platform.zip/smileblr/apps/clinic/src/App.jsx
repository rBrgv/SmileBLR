import { useEffect, useState } from 'react'
import { Routes, Route } from 'react-router-dom'
import { sb } from './lib/supabase'
import { ToastProvider } from './components/Toast'
import Layout from './components/Layout'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import Bookings from './pages/Bookings'
import Patients from './pages/Patients'
import PatientDetail from './pages/PatientDetail'
import Appointments from './pages/Appointments'
import Invoices from './pages/Invoices'
import Recall from './pages/Recall'
import Treatments from './pages/Treatments'
import Inventory from './pages/Inventory'
import Staff from './pages/Staff'

export default function App() {
  const [session, setSession] = useState(undefined) // undefined = loading

  useEffect(() => {
    sb.auth.getSession().then(({ data }) => setSession(data.session))
    const { data: sub } = sb.auth.onAuthStateChange((_e, s) => setSession(s))
    return () => sub.subscription.unsubscribe()
  }, [])

  if (session === undefined) return <div className="empty" style={{ marginTop: '20vh', border: 'none' }}>Loading…</div>
  if (!session) return <ToastProvider><Login /></ToastProvider>

  return (
    <ToastProvider>
      <Routes>
        <Route element={<Layout />}>
          <Route path="/" element={<Dashboard />} />
          <Route path="/bookings" element={<Bookings />} />
          <Route path="/patients" element={<Patients />} />
          <Route path="/patients/:id" element={<PatientDetail />} />
          <Route path="/appointments" element={<Appointments />} />
          <Route path="/invoices" element={<Invoices />} />
          <Route path="/recall" element={<Recall />} />
          <Route path="/treatments" element={<Treatments />} />
          <Route path="/inventory" element={<Inventory />} />
          <Route path="/staff" element={<Staff />} />
        </Route>
      </Routes>
    </ToastProvider>
  )
}
