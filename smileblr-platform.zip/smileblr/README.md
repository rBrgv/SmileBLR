# Smile Bengaluru — Platform

Monorepo for the Smile Bengaluru digital platform.

```
smileblr/
├── apps/
│   ├── web/        Marketing site (smilebengaluru.com) — static, GitHub Pages
│   └── clinic/     Clinic management app — React + Vite + Vercel functions
└── supabase/
    └── migrations/ Versioned database schema (source of truth)
```

## Deploys

| App | Host | How |
|---|---|---|
| apps/web | GitHub Pages (repo rBrgv/SmileBLR) | push index.html |
| apps/clinic | Vercel (root directory = `apps/clinic`) | git push → auto build |
| supabase | Supabase project `smile` (cdvrkcrcpmaqaaffdfgm) | run migrations in SQL editor, in order |

## Clinic app — local dev

```bash
cd apps/clinic
npm install
cp .env.example .env    # fill VITE_SUPABASE_ANON_KEY
npm run dev
```

## Vercel setup (one time)

1. vercel.com → New Project → import this repo
2. Root Directory: `apps/clinic`  ·  Framework: Vite
3. Environment variables:
   - `VITE_SUPABASE_URL` = https://cdvrkcrcpmaqaaffdfgm.supabase.co
   - `VITE_SUPABASE_ANON_KEY` = (anon public key)
   - `WA_ACCESS_TOKEN` = (Meta permanent token — server only)
   - `WA_PHONE_NUMBER_ID` = 1188057101050294
   - `INTERNAL_API_KEY` = (any long random string; the app sends it when calling /api/wa-send)
4. Deploy. App at https://<project>.vercel.app — later map clinic.smilebengaluru.com via CNAME.

WhatsApp automation lives in `apps/clinic/api/wa-send.js` — the Meta token never reaches the browser.
